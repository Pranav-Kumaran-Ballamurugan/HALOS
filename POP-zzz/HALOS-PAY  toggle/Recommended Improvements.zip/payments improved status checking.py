class PaymentStatus(str, Enum):
    PAID = "paid"
    UNPAID = "unpaid"
    NO_PAYMENT = "no_payment_required"

def get_checkout_status(session_id: str) -> Dict:
    """Enhanced with enum status and expanded details"""
    session = stripe.checkout.Session.retrieve(
        session_id,
        expand=['payment_intent', 'customer']
    )
    
    return {
        "status": PaymentStatus(session.payment_status),
        "customer": session.customer,
        "payment_intent": session.payment_intent,
        "receipt_url": session.payment_intent.charges.data[0].receipt_url if session.payment_intent else None
    }