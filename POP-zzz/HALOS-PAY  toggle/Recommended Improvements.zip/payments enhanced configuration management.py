from enum import Enum

class PaymentMode(str, Enum):
    PAYMENT = "payment"
    SUBSCRIPTION = "subscription"

class StripeConfig:
    """Enhanced configuration with type safety"""
    PRODUCT_NAME = os.getenv("PRODUCT_NAME", "HALOS Pro License")
    CURRENCY = os.getenv("CURRENCY", "usd").lower()
    MODE = PaymentMode(os.getenv("PAYMENT_MODE", "payment"))
    
    @staticmethod
    def get_urls() -> dict:
        return {
            "success": os.getenv("STRIPE_SUCCESS_URL", "http://localhost/payment-success"),
            "cancel": os.getenv("STRIPE_CANCEL_URL", "http://localhost/payment-cancel")
        }