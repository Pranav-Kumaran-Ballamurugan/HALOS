import stripe
stripe.default_http_client = stripe.http_client.AsyncHTTPClient()

async def create_checkout_async(amount: float, user_info: Dict) -> str:
    """Async version of checkout creation"""
    session = await stripe.checkout.Session.create(
        # ... same parameters ...
    )
    return session.url