import logging

logger = logging.getLogger(__name__)

# In error handlers:
logger.error(f"Stripe API error: {str(e)}", exc_info=True, extra={
    'context': {
        'amount': amount,
        'user_email': user_info.get('email')
    }
})