def create_stripe_checkout(amount: float, user_info: Dict, payment_methods: list = None):
    """Enhanced with payment method flexibility"""
    session_params = {
        "payment_method_types": payment_methods or ["card"],
        # ... other params ...
    }
    
    if StripeConfig.MODE == PaymentMode.SUBSCRIPTION:
        session_params["line_items"] = [{
            "price": os.getenv("STRIPE_PRICE_ID"),
            "quantity": 1
        }]
        session_params["mode"] = "subscription"
    # ... rest of implementation ...