# HALOS

HALOS is an experimental AI-powered assistant built to help with writing and comprehension, especially for students with dysgraphia or similar challenges. Inspired by fiction, driven by necessity.

## Features

- Emotion-based context writing
- Draft and suggestion assistant
- Custom task handling (assignments, story outlines)

## Status

Actively in development. Built with help from AI tools and ongoing self-learning.

